/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Beans.iteminfo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 *
 * @author MG9__
 */

public class Servlet extends HttpServlet {

private Connection myCon;
private Statement myStmt;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    @Override
  public void init() {

// Instantiate the driver for MySQL
    try {
      Class.forName("com.mysql.jdbc.Driver").newInstance();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

// Create the connection to the db
    try {
      myCon = DriverManager.getConnection ("jdbc:mysql://localhost/items?user=root");
	//When you upload, use this statement instead:
      //myCon = DriverManager.getConnection("cjdbc:mysql://localhost:3306/ex_cars?user=ex_cars&password=9a0zns83ve40as98345hnv?autoReconnect=true"); //hostgator
    }
    catch (SQLException e) {
      e.printStackTrace();
    }

// Create the statement for SQL queries
    try {
      myStmt = myCon.createStatement();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }  //** end of the init method
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
        
        
        
        String param1 = request.getParameter("Barcode");
         String query = "SELECT * FROM Items WHERE Barcode="+param1;
           //Perform the query:
    try {

	//Or if it's a SELECT, use:
    ResultSet  result = myStmt.executeQuery(query);
	//If it's a select (i.e. there is a 'result') you can get the result meta data (names of the columns and number of returned rows):
	//Get the result's metadata and the number of columns
     ResultSetMetaData resultMd = result.getMetaData();
    //  int numCols = resultMd.getColumnCount();
	//  You can loop through the resultSet using this code:
    
  iteminfo item = new iteminfo ();
     while (result.next()) {
        	
     item.setBarcode(result.getString("Barcode"));
     item.setName(result.getString("Name"));
     item.setPrice(result.getInt("Price"));
     item.setQuantity(result.getInt("Quantity"));
         
       request.setAttribute("item", item);   
     
         
       //  request.setAttribute("Barcode", param1);
request.getRequestDispatcher("details.jsp").forward(request, response);
      //   response.sendRedirect("details.jsp");

      }
	  
     
     
    
         response.sendRedirect("index.html");
     
     
	   }  //** end of try
           catch (Exception e) {
      e.printStackTrace();
       out.println("<p>Error</p>");
      out.println("<p>"+e.getLocalizedMessage()+"</p>");
    }  //** end of catch
	
    }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
