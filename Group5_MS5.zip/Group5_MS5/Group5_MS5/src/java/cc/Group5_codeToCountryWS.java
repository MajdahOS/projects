/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc;

import static cc.Group5_codeToCountryWS.country.KSA;
import static cc.Group5_codeToCountryWS.country.Kuwait;
import static cc.Group5_codeToCountryWS.country.UAE;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Reema
 */
@WebService(serviceName = "Group5_codeToCountryWS")
public class Group5_codeToCountryWS {

    /**
     * This is a sample web service operation
     */
    
     public enum country{
       KSA, UAE, Kuwait
   }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "countryFromCode")
    public country countryFromCode(@WebParam(name = "countryPhoneCode") String countryPhoneCode) {
        //TODO write your implementation code here:
        
        if(countryPhoneCode.equals("00971"))
            return UAE;
         if(countryPhoneCode.equals("00965"))
            return Kuwait;
         
          if(countryPhoneCode.equals("00966"))
            return KSA;
          
          
        return null;
    }
     
     

}
